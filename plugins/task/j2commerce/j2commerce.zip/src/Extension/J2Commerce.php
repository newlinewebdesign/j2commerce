<?php

declare(strict_types=1);

/**
 * @package     J2Commerce
 * @subpackage  plg_task_j2commerce
 *
 * @copyright   (C)2024-2026 J2Commerce, LLC <https://www.j2commerce.com>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace J2Commerce\Plugin\Task\J2Commerce\Extension;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Event\SubscriberInterface;

\defined('_JEXEC') or die;

final class J2Commerce extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;
    use TaskPluginTrait;

    private const TASKS_MAP = [
        'j2commerce.removeNewOrders' => [
            'langConstPrefix' => 'PLG_TASK_J2COMMERCE_REMOVE_NEW_ORDERS',
            'method'          => 'removeNewOrders',
            'form'            => 'removeNewOrders',
        ],
    ];

    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList'    => 'advertiseRoutines',
            'onExecuteTask'        => 'standardRoutineHandler',
            'onContentPrepareForm' => 'enhanceTaskItemForm',
        ];
    }

    private function removeNewOrders(ExecuteTaskEvent $event): int
    {
        $params        = $event->getArgument('params');
        $olderThanDays = (int) ($params->older_than_days ?? 30);
        $dryRun        = (int) ($params->dry_run ?? 1);

        $db    = $this->getDatabase();
        $query = $db->createQuery();
        $now   = $db->quote((new \DateTime('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s'));

        $query->select($db->quoteName(['j2commerce_order_id', 'order_id']))
            ->from($db->quoteName('#__j2commerce_orders'))
            ->where($db->quoteName('order_state_id') . ' = :stateId')
            ->bind(':stateId', $stateId = 5, ParameterType::INTEGER);

        if ($olderThanDays > 0) {
            $days = -1 * $olderThanDays;
            $query->where(
                $db->quoteName('created_on') . ' < ' . $query->dateAdd($now, $days, 'DAY')
            );
        }

        $db->setQuery($query);
        $orders = $db->loadObjectList();

        if (empty($orders)) {
            $this->logTask('No abandoned orders found matching criteria.');
            return Status::OK;
        }

        $orderIds    = array_column($orders, 'j2commerce_order_id');
        $orderVarIds = array_column($orders, 'order_id');
        $count       = \count($orderIds);

        $this->logTask(\sprintf(
            '%s %d abandoned order(s): %s',
            $dryRun ? '[DRY RUN] Would delete' : 'Deleting',
            $count,
            implode(', ', $orderVarIds)
        ));

        if ($dryRun) {
            $this->logTask('Dry run complete. No records were deleted.');
            return Status::OK;
        }

        $db->transactionStart();

        try {
            // Delete orderitemattributes first (FK: orderitem_id -> orderitems)
            $subQuery = $db->createQuery()
                ->select($db->quoteName('j2commerce_orderitem_id'))
                ->from($db->quoteName('#__j2commerce_orderitems'))
                ->whereIn($db->quoteName('order_id'), $orderVarIds, ParameterType::STRING);

            $deleteQuery = $db->createQuery()
                ->delete($db->quoteName('#__j2commerce_orderitemattributes'))
                ->where($db->quoteName('orderitem_id') . ' IN (' . $subQuery . ')');
            $db->setQuery($deleteQuery)->execute();

            // Delete from tables linked by order_id (varchar)
            $orderIdTables = [
                '#__j2commerce_orderitems',
                '#__j2commerce_orderinfos',
                '#__j2commerce_orderhistories',
                '#__j2commerce_ordershippings',
                '#__j2commerce_orderdiscounts',
                '#__j2commerce_orderfees',
                '#__j2commerce_orderdownloads',
                '#__j2commerce_ordertaxes',
            ];

            foreach ($orderIdTables as $table) {
                $deleteQuery = $db->createQuery()
                    ->delete($db->quoteName($table))
                    ->whereIn($db->quoteName('order_id'), $orderVarIds, ParameterType::STRING);
                $db->setQuery($deleteQuery)->execute();
            }

            // Delete the orders themselves
            $deleteQuery = $db->createQuery()
                ->delete($db->quoteName('#__j2commerce_orders'))
                ->whereIn($db->quoteName('j2commerce_order_id'), $orderIds, ParameterType::INTEGER);
            $db->setQuery($deleteQuery)->execute();

            $db->transactionCommit();
        } catch (\Throwable $e) {
            $db->transactionRollback();
            $this->logTask(\sprintf('ERROR: %s', $e->getMessage()));
            return Status::KNOCKOUT;
        }

        $this->logTask(\sprintf('Successfully deleted %d abandoned order(s).', $count));

        return Status::OK;
    }
}
